# Deployment-Deep-Learning-Model


In this project you will find a machine learning model to classify different types of blood cancer.

The model is trained with nearly 10000 images which consist of four classes ALL, AML, CML, CLL.

Each class has roughly 2500 images.


## Build on Azure

New update coming soon!!!
